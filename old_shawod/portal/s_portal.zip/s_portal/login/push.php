<?php
if(isset($_POST['emails'])){
    include "../connect.php";
if(filter_var($_POST['emails'] , FILTER_VALIDATE_EMAIL) ){
    $email=$_POST['emails'];
    $query=mysqli_query($conn,"SELECT * FROM not_approved WHERE email='$email'");
    if(mysqli_num_rows($query)== 1){

    }else{
        echo "Your email dose'nt exists to the database";
    }
}else{
    echo "Invalid email address";
}
}

?>



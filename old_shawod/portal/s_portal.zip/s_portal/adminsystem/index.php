<?php
 header('location:login');
 ?>
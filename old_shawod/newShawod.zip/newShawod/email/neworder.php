<!DOCTYPE>
<html>
<title></title>
    <head>

    </head>
     <style>
         body{
             background-color: rgb(234,237,238);
         }
     </style>
<body>
  <form action="index.php" method="post">
      <input type="email" name="email">
      <input  type="submit">
  </form>
</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title id="title">S E O | Shawod</title>
</head>
<!--x_large -->
<link rel="stylesheet" href="../css/x_large.css" type="text/css" >


<link rel="icon" type="image/ico" href="../thumbnails/favc.png">

<script src="../js/normal.js"></script>
<script src="../js/form_validation.js"></script>


<body>
<div  id="scroll_up" style="background-color:#333333;" onclick="scroll_ups()">
    <img src="../thumbnails/go%20up2.png" width="79px" style="margin-top: 6px" >
</div>
<div class="log">
    <a href="../home"><img src="../thumbnails/logog.png"></a>
</div>
<div class="navs">
    <ul>
        <li>
            <a href="../home" style=" opacity:1"> Home </a>

        </li>

        <div class="dv"></div>
        <li><a href="../website" style=" margin-left:-20%" >Website</a></li>

        <div class="dv" ></div>
        <li id="pg"><a href="../packages" style="margin-left:-30%"> Packages</a>
        </li>
        <div class="dv" ></div>
        <li><a href="../portfolio" style="margin-left: -15px"  >Portfolio</a></li>

        <div id="bt_hold" onclick="opn()">
            <div id="bt1"></div>
            <div ></div>
            <div></div>
        </div>
            
        </li>

        <div id="pg_dv" class="dv"></div>
        <li id="sv"  onmouseover="sub_link('service_div')" onmouseout="sub_out('service_div')"><a style="cursor: pointer;color: rgb(140,140,140)"> Services </a></li>
    </ul><div id="service_div" onmouseover="sub_link('service_div')" onmouseout="sub_out('service_div')">
        <a style="text-decoration:none;color:none" href="../seo"><div  id="seo" onmouseover="sub_link('service_div')" onmouseout="sub_out('service_div')">S.E.O</div></a>
        <a href="../domain" style="text-decoration:none;"><div id="server" onmouseover="sub_link('service_div')" onmouseout="sub_out('service_div')">Domain</div></a>
        <a href="../hosting" style="text-decoration:none;"><div  id="qoute" onmouseover="sub_link('service_div')" onmouseout="sub_out('service_div')">Hosting</div></a>
    </div>
</div>
<br><br><br>

<div  align="center" class="h_intro">
    <div align="center" class="intro_div">
        <span style="color: rgb(102,204,255)">Search Engine Optimization Explained !</span>
    </div>
</div>

<div align="center" style="width: 1300px">
    <h2 style="color: white"><u>S E O</u></h2>
    <p align="left" style="color: white;opacity: .6; margin-left: 100px">
        SEO stands for Search Engine Optimization and it is the process of optimizing your website and online
        presence in order for Google to rank your website organically. What does organic <br> or natural rankings mean?
        It means that Google will look at your website and online profile and decide for which keywords they will
        rank you on the first page of the search engine results</p>
    </p>
    <p align="left" style="color: white;opacity: .6;margin-left: 100px">
        The consultants at Shawod are search engine optimization experts.
        We can help your site achieve top rankings on major search engines by implementing our thorough, common sense methodology.
    </p>
    <h2 align="left" style="color: white; margin-left: 100px"><u>Basic S E O</u></h2>
    <p align="left" style="color: white; margin-left: 100px;opacity: .6"><b>.</b> Off-page SEO</p>
    <p align="left" style="color: white; margin-left: 100px;opacity: .6"><b>.</b> Robots</p>
    <p align="left" style="color: white; margin-left: 100px;opacity: .6"><b>.</b> Sitemap</p>

    <h2 align="left" style="color: white; margin-left: 100px"><u>Premium S E O</u></h2>
    <p align="left" style="color: white; margin-left: 100px;opacity: .6"><b>.</b> keywords</p>
    <p align="left" style="color: white; margin-left: 100px;opacity: .6"><b>.</b> Metatags</p>
    <p align="left" style="color: white; margin-left: 100px;opacity: .6"><b>.</b> On-page SEO</p>
    <p align="left" style="color: white; margin-left: 100px;opacity: .6"><b>.</b> With all the basic SEO benefits</p>

    <h2 align="left" style="color: white; margin-left: 100px"><u>Ultimate S E O</u></h2>
    <p align="left" style="color: white; margin-left: 100px;opacity: .6"><b>.</b> Search Engine Submissions</p>
    <p align="left" style="color: white; margin-left: 100px;opacity: .6"><b>.</b> Reports</p>
    <p align="left" style="color: white; margin-left: 100px;opacity: .6"><b>.</b> Directory Submission</p>
    <p align="left" style="color: white; margin-left: 100px;opacity: .6"><b>.</b> Local listings </p>
    <p align="left" style="color: white; margin-left: 100px; opacity: .6"><b>.</b> With all the Premium SEO benefits</p>

    <p align="left" style="color: white; opacity: 1; margin-left: 100px">Most top-ranking websites, the ones that appear "naturally" at the top of the search engine page just below the paid ads,
    do not appear there accidentally, they've been carefully designed and optimized to beat the competition to the top of the
        page by professionals like us.<br><br>
        Recommended Time-Frame for Best Results: 3 - 6 Months and if you buy the SEO at Shawod you get the SEO for the whole year.</p>
</div>

<?php require '../footer/footer.php' ?>

</body>
</html>
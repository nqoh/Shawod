<?php
 header("location:login");
?>
<?php
if(isset($_POST['emails'])){

if(filter_var($_POST['emails'] , FILTER_VALIDATE_EMAIL) ){
}else{
    echo "Invalid email address";
}
}

?>



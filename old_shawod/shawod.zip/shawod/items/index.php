<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title id="title">Items | Shawod</title>
</head>
<!--x_large -->
<link rel="stylesheet" href="../css/x_large.css" type="text/css" >


<link rel="icon" type="image/ico" href="../thumbnails/favd.png">

<script src="../js/normal.js"></script>
<script src="../js/form_validation.js"></script>


<body>
<div  id="scroll_up" style="background-color:#333333;" onclick="scroll_ups()">
    <img src="../thumbnails/go%20up2.png" width="79px" style="margin-top: 6px" >
</div>
<div class="log">
    <a href="../home"><img src="../thumbnails/logog.png"></a>
</div>
<div class="navs">
    <ul>
        <li>
            <a href="../home" style=" opacity:1"> Home </a>

        </li>
        <div class="dv"></div>
        <li><a href="../website" style=" margin-left:-20%" >Website</a></li>

        <div class="dv" ></div>
        <li id="pg"><a href="../packages" style="margin-left:-30%"> Packages</a>
        </li>
        <div class="dv" ></div>
        <li><a href="../portfolio" style="margin-left: -15px"  >Portfolio</a></li>

        <div id="bt_hold" onclick="opn()">
            <div id="bt1"></div>
            <div ></div>
            <div></div>
        </div>


        </li>

        <div id="pg_dv" class="dv"></div>
        <li id="sv"  onmouseover="sub_link('service_div')" onmouseout="sub_out('service_div')"><a style="cursor: pointer"> Services </a></li>
    </ul><div id="service_div" onmouseover="sub_link('service_div')" onmouseout="sub_out('service_div')">
        <a style="text-decoration:none;color:none" href="../seo"><div  id="seo" onmouseover="sub_link('service_div')" onmouseout="sub_out('service_div')">S.E.O</div></a>
        <a href="../domain" style="text-decoration:none;"><div id="server" onmouseover="sub_link('service_div')" onmouseout="sub_out('service_div')">Domain</div></a>
        <a href="../hosting" style="text-decoration:none;"><div  id="qoute" onmouseover="sub_link('service_div')" onmouseout="sub_out('service_div')">Hosting</div></a>
    </div>
</div><br><br><br>

<div  align="center" class="h_intro">
    <div align="center" class="intro_div">
        <span style="color: rgb(102,204,255)"> Optional items !</span>
    </div>
</div>

<div align="center" style="width: 1300px">
    <h2 align="left"  style="color: white; margin-left: 100px"><u>Page</u></h2>
    <p align="left" style="color: white;opacity: .6; margin-left: 100px;margin-top: -10px">A page is a webpage with unlimited text and not more than two images.</p>
    </p><p align="left" style="color: white;opacity: .6; margin-left: 100px;margin-top: -10px">Please note: pages do not include forms unless forms are separately bought.</p>

    <h2 align="left"  style="color: white; margin-left: 100px"><u>Content Management Systems</u></h2>
    <p align="left" style="color: white;opacity: .6; margin-left: 100px;margin-top: -10px">Imagine never having to call your web designer or developer again. If you can operate a web browser and you're
    familiar with Microsoft Word, you can easily maintain your own<br> web site and content.
    The number of Content management system is the number of pages you want to manage,
        so if for example you want manage 4 pages of your website add 4 CMS.</p>
    <h2 align="left"  style="color: white; margin-left: 100px"><u>S E O</u></h2>
    <p align="left" style="color: white;opacity: .6; margin-left: 100px;margin-top: -10px">SEO stands for Search Engine Optimization and it is the process of optimizing your website and
    online presence in order for Google to rank your website organically. What does organic or natural
    rankings mean? It means that Google will look at your website and online profile and decide for which
    keywords they will rank you on the first page of the search engine results
    Recommended Time-Frame for Best Results: 3 - 6 Months and if you buy the SEO at
        Shawod you get the SEO for the whole year</p>
    <p align="left" style="color: white;opacity: .6; margin-left: 100px;margin-top: -10px">Also refer to the <a href="../seo" class="alink">SEO explained page</a> for more clarity on Basic, Premium and Ultimate.</p>
    <h2 align="left"  style="color: white; margin-left: 100px"><u>Privacy Protection</u></h2>
    <p align="left" style="color: white;opacity: .6; margin-left: 100px;margin-top: -10px">Hides your personal information - name, email, address and phone number - in the public WHOIS directory</p>
    <p align="left" style="color: white;opacity: .6;  margin-left: 100px;margin-top: -10px"> Prevents domain-related spam</p>
    <p align="left" style="color: white;opacity: .6;  margin-left: 100px;margin-top: -10px"> Helps stop domain hijacking</p>
    <p align="left" style="color: white;opacity: .6;  margin-left: 100px;margin-top: -10px"> Helps protect against stalkers and harassers</p>
    <p align="left" style="color: white; margin-left: 100px;margin-top: -10px"><u>example</u></p>
    <p align="left" style="color: white;  margin-left: 100px;margin-top: -10px"> Your info without privacy</p>
    <p align="left" style="color: white;opacity: .6;  margin-left: 100px;margin-top: -10px"> Jane Smith</p>
    <p align="left" style="color: white;opacity: .6;  margin-left: 100px;margin-top: -10px"> jane@BusinessExample.com</p>
    <p align="left" style="color: white;opacity: .6;  margin-left: 100px;margin-top: -10px"> 1234 Elm Street</p>
    <p align="left" style="color: white;opacity: .6;  margin-left: 100px;margin-top: -10px"> Hometown, AZ 85000</p>
    <p align="left" style="color: white;opacity: .6;  margin-left: 100px;margin-top: -10px"> (480) 555-5555</p>
    <p align="left" style="color: white; margin-left: 100px;margin-top: -10px"> Your info with privacy</p>
    <p align="left" style="color: white;opacity: .6;  margin-left: 100px;margin-top: -10px"> DomainsByProxy.com</p>
    <p align="left" style="color: white;opacity: .6;  margin-left: 100px;margin-top: -10px"> ProxiedDomain@DomainsByProxy.com</p>
    <p align="left" style="color: white;opacity: .6;  margin-left: 100px;margin-top: -10px"> 14747 N Northsight Blvd</p>
    <p align="left" style="color: white;opacity: .6;  margin-left: 100px;margin-top: -10px"> Suite 111, PMB 309</p>
    <p align="left" style="color: white;opacity: .6;  margin-left: 100px;margin-top: -10px"> Scottsdale, AZ 85260</p>
    <p align="left" style="color: white;opacity: .6;  margin-left: 100px;margin-top: -10px"> +1.480.642.2599</p>

    <h2 align="left"  style="color: white; margin-left: 100px"><u>Protected Registration</u></h2>
    <p align="left" style="color: white;opacity: .6;  margin-left: 100px;margin-top: -10px">Privacy hides your personal information from public view in the WHOIS directory.
        Domain Ownership Protection prevents accidental domain expiration or malicious transfer.<br>
        Certified Domain Seal proves to visitors that your site's ownership is valid.
        Business Registration creates an online business card in the WHOIS directory
    </p>
    <h2 align="left"  style="color: white; margin-left: 100px"><u>Advanced Social Media Integration</u></h2>
    <p align="left" style="color: white;opacity: .6;  margin-left: 100px;margin-top: -10px">Although we do link your Social Media accounts on your website free of charge, what this ASMI actually does is
        its integrates your social media newsfeed to the website.<br> For example: Comments made on your facebook page can also appear on your website.
    </p>

    <h2 align="left"  style="color: white; margin-left: 100px"><u>Shared Hosting</u></h2>
    <p align="left" style="color: white;opacity: .6;  margin-left: 100px;margin-top: -10px">
    In a shared hosting environment multiple web sites are served through a single server. Shared hosting is the most common method
        of hosting sites for small-to-medium size <br> users with light to moderate Web traffic.</p>
    <p align="left" style="color: white;opacity: .6;  margin-left: 100px;margin-top: -10px">
         Economy  <br>
         Dulux  <br>
        Premium </p>
    <h2 align="left"  style="color: white; margin-left: 100px"><u>Economy Host</u></h2>
    <p align="left" style="color: white;opacity: .6;  margin-left: 100px;margin-top: -10px">
    Economy Hosting is an entry-level shared hosting, this is for websites with very little traffic but want to keep their portfolio online.
    <br>Economy includes the following -:<br>
    Disk Space : 5gig hdd<br>
    Bandwidth : 1tb in-bound and out-bound traffic
    </p>

    <h2 align="left"  style="color: white; margin-left: 100px"><u>Dulux Host</u></h2>
    <p align="left" style="color: white;opacity: .6;  margin-left: 100px;margin-top: -10px">
        Dulux is mid-level Shared Hosting which caters for moderate traffic.
        <br>Dulux includes the following-:<br>
        Disk Space : 5gig + 2gig hdd (mirrored) <br>
        Bandwidth : 2tb in-bound and out-bound
    </p>

    <h2 align="left"  style="color: white; margin-left: 100px"><u>Premium Host</u></h2>
    <p align="left" style="color: white;opacity: .6;  margin-left: 100px;margin-top: -10px">
        Premium shared-hosting is the best in its class and can handle a decent amount of traffic.
        <br>This includes -:<br>
        Disk Space : 5 gig + 5 gig HDD (mirrored) <br>
        Bandwidth : 5tb in-bound and out-bound rate.
    </p>
    <h2 align="left"  style="color: white; margin-left: 100px"><u>General Design</u></h2>
    <p align="left" style="color: white;opacity: .6;  margin-left: 100px;margin-top: -10px">
        general design has the basic layout, this comes as a default for a Bronze website/package</p>

    <h2 align="left"  style="color: white; margin-left: 100px"><u>Premium design</u></h2>
    <p align="left" style="color: white;opacity: .6;  margin-left: 100px;margin-top: -10px">
        This premium design offers a themed layout throughout the website, with eye-catch look.</p>

    <h2 align="left"  style="color: white; margin-left: 100px"><u>Custom design</u></h2>
    <p align="left" style="color: white;opacity: .6;  margin-left: 100px;margin-top: -10px">
        The Custom design includes the Premium design features with your personal touch and a unique-style layout.</p>

    <p align="center" style="color: white;margin-left: 100px;margin-top: -10px">Also refer to the <a href="../faqs" class="alink">Frequently Asked Questions</a>  for more clarity.</p>

</div>
<?php require '../footer/footer.php' ?>
</div>

</body>
</html>
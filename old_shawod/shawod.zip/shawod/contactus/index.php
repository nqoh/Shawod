<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title id="title">Contact us | Shawod</title>


</head>
<!-- x_small -->
<!--<link rel="stylesheet" href="css/x_small.css" type="text/css" media="screen and (min-width: 0px)">
<!--x_large -->
<link rel="stylesheet" href="../css/x_large.css" type="text/css" >


<link rel="icon" type="image/ico" href="../thumbnails/favd.png">

<script src="../js/contactus.js"></script>


<body>
<div  id="scroll_up" style="background-color:#333333;" onclick="scroll_ups()">
    <img src="../thumbnails/go%20up2.png" width="79px" style="margin-top: 6px" >
</div>
<div class="log">
    <a href="../home"><img src="../thumbnails/logog.png"></a>
</div>
<div class="navs">
    <ul>
        <li>
            <a href="../home" style=" opacity:1"> Home </a>

        </li>

        <div class="dv"></div>
        <li><a href="../website" style=" margin-left:-20%" >Website</a></li>

        <div class="dv" ></div>
        <li id="pg"><a href="../packages" style="margin-left:-30%"> Packages</a>
        </li>
        <div class="dv" ></div>
        <li><a href="../portfolio" style="margin-left: -15px"  >Portfolio</a></li>

        <div id="bt_hold" onclick="opn()">
            <div id="bt1"></div>
            <div ></div>
            <div></div>
        </div>
            
        </li>

        <div id="pg_dv" class="dv"></div>
        <li id="sv"  onmouseover="sub_link('service_div')" onmouseout="sub_out('service_div')"><a style="cursor: pointer"> Services </a></li>
    </ul>
    <div id="service_div" onmouseover="sub_link('service_div')" onmouseout="sub_out('service_div')">
        <a style="text-decoration:none;color:none" href="../seo"><div  id="seo" onmouseover="sub_link('service_div')" onmouseout="sub_out('service_div')">S.E.O</div></a>
        <a href="../domain" style="text-decoration:none;"><div id="server" onmouseover="sub_link('service_div')" onmouseout="sub_out('service_div')">Domain</div></a>
        <a href="../hosting" style="text-decoration:none;"><div  id="qoute" onmouseover="sub_link('service_div')" onmouseout="sub_out('service_div')">Hosting</div></a>
    </div>
</div><br><br><br>

<div  align="center" class="h_intro">
    <div align="center" class="intro_div">
        <span style="color: rgb(102,204,255)">Contact us</span>
    </div>
</div>

<div  style="width: 1320px">
    <h3 style="color: white" align="center"><u>If you have any queries or want to chat about your Project please go right ahead.</u></h3>
    <h4 style="color: white" align="center"> Our team is always standing by to assist you.</h4>

    <div class="form" style="margin-top: -10px; box-shadow: 0px 0px 0px 0px; border: 1px solid white; opacity: 1; border-radius:    10%; width: 560px">
        <span class="fill_in">Complete this form, one of our expects will get back to you.</span><br>

        <br><label class="lebel">Name<span style="color:red"> * </span></label><span style="color: red" id="namee_error"></span><br><br>
        <input type="text" class="text-field3" id="namee" onblur="name_out('namee','namee_error')" onfocus="mouse_in('namee')"><br>

        <br><label class="lebel">E-mail<span style="color:red"> * </span></label><span id="emaile_error" style="color: red"></span><br><br>

        <input type="text" class="text-field3" id="emaile" onblur="check_email('emaile','emaile_error')" onfocus="mouse_in('emaile')" ><br>

        <br><label class="lebel">Subject</label>&nbsp;&nbsp;<span id="sub_error" style="color: red"></span><br><br>
        <input type="text" class="text-field3" id="subjs" onblur="subj('subjs','sub_error')"  onfocus="mouse_in('subjs') "><br>

        <br><label class="lebel">Query<span style="color:red"> * </span></label><span style="color: red" id="describes_error"></span><br><br>

        <div type="text" style=" border: 1px solid #ccc;" contenteditable="true" id="textareas" onblur="texts('textareas','describes_error')" onfocus="mouse_in('textareas')" ></div>


        <div class="silver_btn" id="cont_btn"  style="box-shadow: 0px 0px 0px 0px; width: 150px"   onclick="send_data('namee','emaile','subjs','textareas')" >
            <span style="color: rgb(255,255,255); " > <b>Submit</b> </span>
        </div>
        <span id="reference"></span>

    </div><br>
</div>

<?php require '../footer/footer.php' ?>

</body>
</html>
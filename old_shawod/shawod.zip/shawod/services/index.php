<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Services | Shawod</title>
</head>

<!--x_large -->
<link rel="stylesheet" href="../css/x_large.css" type="text/css">
<link rel="icon" type="image/ico" href="../thumbnails/favc.png">
<script src="../js/normal.js"></script>

<body>
<div  id="scroll_up" style="background-color:#333333;" onclick="scroll_ups()">
    <img src="../thumbnails/go%20up2.png" width="79px" style="margin-top: 6px" >
</div>

<div class="navs">
    <ul>
        <li>
            <a href="../home"> Home </a>
        </li>

        <div class="dv"></div>
        <li><a href="../website" style=" margin-left:-20%" >Website</a></li>

        <div class="dv" ></div>
        <li id="pg"><a href="../packages" style="margin-left:-30%"> Packages</a>
        </li>
        <div class="dv" ></div>
        <li><a href="../portfolio" style="margin-left: -15px"  >Portfolio</a></li>

        <div id="bt_hold" onclick="opn()">
            <div id="bt1"></div>
            <div ></div>
            <div></div>
        </div>


        </li>
        <div id="pg_dv" class="dv"></div>
        <li id="sv"><a href="../services"> Services</a>
            <div class="s"></div>
        </li><div id="service_div" onmouseover="sub_link('service_div')" onmouseout="sub_out('service_div')">
            <a style="text-decoration:none;color:none" href="../seo"><div  id="seo" onmouseover="sub_link('service_div')" onmouseout="sub_out('service_div')">S.E.O</div></a>
            <a href="../domain" style="text-decoration:none;"><div id="server" onmouseover="sub_link('service_div')" onmouseout="sub_out('service_div')">Domain</div></a>
            <a href="../hosting" style="text-decoration:none;"><div  id="qoute" onmouseover="sub_link('service_div')" onmouseout="sub_out('service_div')">Hosting</div></a>
        </div>

    </ul><div id="service_div" onmouseover="sub_link('service_div')" onmouseout="sub_out('service_div')">
    <div  id="seo" onmouseover="sub_link('service_div')" onmouseout="sub_out('service_div')">S.E.O</div>
    <div id="server" onmouseover="sub_link('service_div')" onmouseout="sub_out('service_div')">Server Migration</div>
    <div  id="qoute" onmouseover="sub_link('service_div')" onmouseout="sub_out('service_div')">Get a quote</div>
</div>

<br><br><br>

<div  align="center" class="h_intro">
    <div align="center" class="intro_div">
        <span style="color: rgb(102,204,255)">Services</span>
    </div>
</div>

</body>
</html>
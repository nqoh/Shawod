<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title id="title">Portfolio | Shawod</title>


</head>

<!--x_large -->
<link rel="stylesheet" href="../css/x_large.css" type="text/css" >

<link rel="icon" type="image/ico" href="../thumbnails/favd.png">
<script src="../js/portfolio.js"></script>
<script src="../js/normal.js"></script>
<script src="../js/form_validation.js"></script>


<body>
<div  id="scroll_up" style="background-color:#333333;" onclick="scroll_ups()">
    <img src="../thumbnails/go%20up2.png" width="79px" style="margin-top: 6px" >
</div>
<div class="log">
      <a href="../home"><img src="../thumbnails/logog.png"></a>
</div>

<div class="navs">
    <ul>
        <li>
            <a href="../home" style=" opacity:1"> Home </a>

        </li>
        <div class="dv"></div>
        <li><a href="../website" style=" margin-left:-20%" >Website</a></li>

        <div class="dv" ></div>
        <li id="pg"><a href="../packages" style="margin-left:-30%"> Packages</a>
        </li>
        <div class="dv" ></div>
        <li><a href="../portfolio" style="color: rgb(140,140,140);margin-left: -15px"  >Portfolio</a></li>

        <div id="bt_hold" onclick="opn()">
            <div id="bt1"></div>
            <div ></div>
            <div></div>
        </div>

        </li>

        <div id="pg_dv" class="dv"></div>
        <li id="sv"  onmouseover="sub_link('service_div')" onmouseout="sub_out('service_div')"><a style="cursor: pointer"> Services </a></li>
    </ul>
    <div id="service_div" onmouseover="sub_link('service_div')" onmouseout="sub_out('service_div')">
        <a style="text-decoration:none;color:none" href="../seo"><div  id="seo" onmouseover="sub_link('service_div')" onmouseout="sub_out('service_div')">S.E.O</div></a>
        <a href="../domain" style="text-decoration:none;"><div id="server" onmouseover="sub_link('service_div')" onmouseout="sub_out('service_div')">Domain</div></a>
        <a href="../hosting" style="text-decoration:none;"><div  id="qoute" onmouseover="sub_link('service_div')" onmouseout="sub_out('service_div')">Hosting</div></a>
    </div></div><br><br><br>

<div  align="center" class="h_intro">
    <div align="center" class="intro_div">
        <span style="color: rgb(102,204,255)">Portfolio</span>
    </div>
</div>
<div style="padding-left: 80px ; padding-right: 0px; width: 1200px ">
    <h1 align="left" style="color: white">Have a look at our mock ups below</h1>
    <p align="left" style="font-size: 32px;color: rgb(102,204,255); margin-bottom: -10px; margin-top: -10px">Book a Car</p>
    <p align="left" style="color: silver; margin-left: 20px">Car dealership</p>

    <div align="left" style="margin-left: 50px">
        <img src="../thumbnails/bac1.PNG" width="750px" >
    </div><br>
    <span class="opn" id="sp1" onclick="views1('sp1','dv1')">More</span><br><br>
    <div align="left" style="margin-left: 50px; display: none" id="dv1">
        <img src="../thumbnails/bac2.PNG" width="372px" style="float: left;" >
        <img src="../thumbnails/bac3.PNG" width="372px" style="margin-left: 5px; clear: left" >
    </div><br>

    <p align="left" style="font-size: 32px;color: rgb(102,204,255); margin-bottom: -10px; margin-top: -10px">DARK Sky (designs)</p>
    <p align="left" style="color: silver; margin-left: 20px">Furniture designs</p>
    <div align="left" style="margin-left: 50px">
        <img src="../thumbnails/ds1.PNG" width="750px" >
    </div><br>
    <span class="opn" id="sp2" onclick="views2('sp2','dv2')">More</span><br><br>
    <div align="left" style="margin-left: 50px;display: none" id="dv2">
        <img src="../thumbnails/ds2.PNG" width="372px" style="float: left;" >
        <img src="../thumbnails/ds3.PNG" width="372px" style="margin-left: 5px; clear: left" >
    </div>
    <br>

    <p align="left" style="font-size: 32px;color: rgb(102,204,255); margin-bottom: -10px; margin-top: -10px">
        Rok the Construction</p>
    <p align="left" style="color: silver; margin-left: 20px">The Construction company</p>

    <div align="left" style="margin-left: 50px">
        <img src="../thumbnails/rtc1.PNG" width="750px" >
    </div><br>
    <span class="opn" id="sp3" onclick="views3('sp3','dv3')">More</span><br><br>
    <div align="left" style="margin-left: 50px; display: none" id="dv3">
        <img src="../thumbnails/rtc2.PNG" width="372px" style="float: left;" >
        <img src="../thumbnails/rtc3.PNG" width="372px" style="margin-left: 5px; clear: left" >
    </div>

</div>
<br><br>
<?php require '../footer/footer.php' ?>


</body>
</html>
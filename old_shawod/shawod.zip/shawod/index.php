
<?php
header('location:home');
?>

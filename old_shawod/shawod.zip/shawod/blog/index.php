<?php
require '../connect.php';
$blog='';$text1='';
$q= mysqli_query($conn,"SELECT * FROM blog");
$images= Array('dns.jpg','webpromo.jpg','smpassword.jpg','smallbiz.jpg');
$i=0;
while ($row=mysqli_fetch_assoc($q)){
    $title=$row['title'];
    $s_title=$row['sub_title'];
    $txt=$row['text'];
    $id=$row['id'];

//    foreach ($txt as $txt2){
//           $text .= $txt2.'<br>';
//    }
if(strlen($txt) > 1140){
    $text1 = substr($txt, 0, 1140 ).' ...';
}
    $blog.="<div  style=\"width: 1300px\">
    <p align=\"left\" style=\"margin-left: 100px; clear: left; margin-bottom: -0px; color:rgb(102, 204, 255); font-size: 36px \">$title</p>
    <span style=\"margin-left: 120px; color: silver; font-size: 12px \">$s_title</span>

    <div style=\"margin-left: 100px\">
        <p style=\"float: left; width: 750px;color: white;opacity: .6;\">
              $text1 <br>
            <a href=\"../blog/$id\" style=\"color:black;color:rgb(102, 204, 255); text-decoration: none\">More...</a>
        </p>
        <img src=\"../thumbnails/$images[$i]\" style=\"width: 400px; height:210px \">
    </div>
</div>";
$i++;


}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title id="title">Blog | Shawod</title>


</head>

<!--x_large -->
<link rel="stylesheet" href="../css/x_large.css" type="text/css">


<link rel="icon" type="image/ico" href="../thumbnails/favd.png">

<script src="../js/normal.js"></script>
<script src="../js/form_validation.js"></script>


<body>
<div  id="scroll_up" style="background-color:#333333;" onclick="scroll_ups()">
    <img src="../thumbnails/go%20up2.png" width="79px" style="margin-top: 6px" >
</div>
<div class="log">
    <a href="../home"><img src="../thumbnails/logog.png"></a>
</div>

<div class="navs">
    <ul>
        <li>
            <a href="../home" style=" opacity:1"> Home </a>

        </li>
        <div class="dv"></div>
        <li><a href="../website" style=" margin-left:-20%" >Website</a></li>

        <div class="dv" ></div>
        <li id="pg"><a href="../packages" style="margin-left:-30%"> Packages</a>
        </li>
        <div class="dv" ></div>
        <li><a href="../portfolio" style="margin-left: -15px"  >Portfolio</a></li>

        <div id="bt_hold" onclick="opn()">
            <div id="bt1"></div>
            <div ></div>
            <div></div>
        </div>

            
        </li>

        <div id="pg_dv" class="dv"></div>
        <li id="sv"  onmouseover="sub_link('service_div')" onmouseout="sub_out('service_div')"><a style="cursor: pointer"> Services </a></li>
    </ul>
    <div id="service_div" onmouseover="sub_link('service_div')" onmouseout="sub_out('service_div')">
        <a style="text-decoration:none;color:none" href="../seo"><div  id="seo" onmouseover="sub_link('service_div')" onmouseout="sub_out('service_div')">S.E.O</div></a>
        <a href="../domain" style="text-decoration:none;"><div id="server" onmouseover="sub_link('service_div')" onmouseout="sub_out('service_div')">Domain</div></a>
        <a href="../hosting" style="text-decoration:none;"><div  id="qoute" onmouseover="sub_link('service_div')" onmouseout="sub_out('service_div')">Hosting</div></a>
    </div>
</div><br><br><br>

<div  align="center" class="h_intro">
    <div align="center" class="intro_div">
        <span style="color: rgb(102,204,255)">Blog</span>
    </div>
</div>
<!--<div  style="width: 1300px">-->
<!--<p align="left" style="color: white; margin-left: 100px; margin-bottom: -20px">Learn more about blog blaaaa blaaa blaaaa-->
<!--     nndasndna asddnsfajeafdfejas blaaaaaa ms amfds fas fjkea, dskjansdfas df fksjenajd sakjf  ksjfejanfdsjnfa fsafjej nfasjd fa</p>-->
<!---->
<!--    <p align="left" style="margin-left: 100px; margin-bottom: -0px; color:rgb(102, 204, 255); font-size: 36px ">Blog insert one</p>-->
<!--    <span style="margin-left: 120px; color: silver; font-size: 12px ">By mlondie | www.olovamp3.com</span>-->
<!---->
<!--    <div style="margin-left: 100px">-->
<!--    <p style="float: left; width: 750px;color: white;opacity: .6;">-->
<!--        mdsfa fjka fsfkjensaf mds afjska f,snfeka fnsiafdmsnfisnfajsknfuiesa fienaf dsfesa,f sfafaf eakf a fa-->
<!--        fslfmesailfd iemaf ieolmasd fosa dfoiea fienadfjhysabksufheaknflaifeioasnfsauiehsaknfiudnasfkdjas faskiufejankfnas-->
<!--        mdsfa fjka fsfkjensaf mds afjska f,snfeka fnsiafdmsnfisnfajsknfuiesa fienaf dsfesa,f sfafaf eakf a fa-->
<!--        fslfmesailfd iemaf ieolmasd fosa dfoiea fienadfjhysabksufheaknflaifeioasnfsauiehsaknfiudnasfkdjas faskiufejankfna-->
<!--        mdsfa fjka fsfkjensaf mds afjska f,snfeka fnsiafdmsnfisnfajsknfuiesa fienaf dsfesa,f sfafaf eakf a fa-->
<!--        fslfmesailfd iemaf ieolmasd fosa dfoiea fienadfjhysabksufheaknflaifeioasnfsauiehsaknfiudnasfkdjas faskiufejankfna-->
<!--        mdsfa fjka fsfkjensaf mds afjska f,snfeka fnsiafdmsnfisnfajsknfuiesa fienaf dsfesa,f sfafaf eakf a fa-->
<!--        fslfmesailfd iemaf ieolmasd fosa dfoiea fienadfjhysabksufheaknflaifeioasnfsauiehsaknfiudnasfkdjas faskiufejankfna-->
<!--        mdsfa fjka fsfkjensaf mds afjska f,snfeka fnsiafdmsnfisnfajsknfuiesa fienaf dsfesa,f sfafaf eakf a fa-->
<!--        fslfmesailfd iemaf ieolmasd fosa dfoiea fienadfjhysabksufheaknflaifeioasnfsauiehsaknfiudnasfkdjas faskiufejankfna-->
<!--        mdsfa fjka fsfkjensaf mds afjska f,snfeka fnsiafdmsnfisnfajsknfuiesa fienaf dsfesa,f sfafaf eakf a fa-->
<!--        fslfmesailfd iemaf ieolmasd fosa dfoiea fienadfjhysabksufheaknflaifeioasnfsauiehsaknfiudnasfkdjas faskiufejankfna<br>-->
<!--        <a href="#" style="color:black; text-decoration: none">More...</a>-->
<!--    </p>-->
<!--        <img src="../thumbnails/bac1.PNG" style="width: 400px">-->
<!--    </div>-->
<!--</div>-->
<!---->
<!---->
<!--<div  style="width: 1300px">-->
<!--    <p align="left" style="margin-left: 100px; clear: left; margin-bottom: -0px; color:rgb(102, 204, 255); font-size: 36px ">Blog insert one</p>-->
<!--    <span style="margin-left: 120px; color: silver; font-size: 12px ">By mlondie | www.olovamp3.com</span>-->
<!---->
<!--    <div style="margin-left: 100px">-->
<!--        <p style="float: left; width: 750px;color: white;opacity: .6;">-->
<!--            mdsfa fjka fsfkjensaf mds afjska f,snfeka fnsiafdmsnfisnfajsknfuiesa fienaf dsfesa,f sfafaf eakf a fa-->
<!--            fslfmesailfd iemaf ieolmasd fosa dfoiea fienadfjhysabksufheaknflaifeioasnfsauiehsaknfiudnasfkdjas faskiufejankfnas-->
<!--            mdsfa fjka fsfkjensaf mds afjska f,snfeka fnsiafdmsnfisnfajsknfuiesa fienaf dsfesa,f sfafaf eakf a fa-->
<!--            fslfmesailfd iemaf ieolmasd fosa dfoiea fienadfjhysabksufheaknflaifeioasnfsauiehsaknfiudnasfkdjas faskiufejankfna-->
<!--            mdsfa fjka fsfkjensaf mds afjska f,snfeka fnsiafdmsnfisnfajsknfuiesa fienaf dsfesa,f sfafaf eakf a fa-->
<!--            fslfmesailfd iemaf ieolmasd fosa dfoiea fienadfjhysabksufheaknflaifeioasnfsauiehsaknfiudnasfkdjas faskiufejankfna-->
<!--            mdsfa fjka fsfkjensaf mds afjska f,snfeka fnsiafdmsnfisnfajsknfuiesa fienaf dsfesa,f sfafaf eakf a fa-->
<!--            fslfmesailfd iemaf ieolmasd fosa dfoiea fienadfjhysabksufheaknflaifeioasnfsauiehsaknfiudnasfkdjas faskiufejankfna-->
<!--            mdsfa fjka fsfkjensaf mds afjska f,snfeka fnsiafdmsnfisnfajsknfuiesa fienaf dsfesa,f sfafaf eakf a fa-->
<!--            fslfmesailfd iemaf ieolmasd fosa dfoiea fienadfjhysabksufheaknflaifeioasnfsauiehsaknfiudnasfkdjas faskiufejankfna-->
<!--            mdsfa fjka fsfkjensaf mds afjska f,snfeka fnsiafdmsnfisnfajsknfuiesa fienaf dsfesa,f sfafaf eakf a fa-->
<!--            fslfmesailfd iemaf ieolmasd fosa dfoiea fienadfjhysabksufheaknflaifeioasnfsauiehsaknfiudnasfkdjas faskiufejankfna<br>-->
<!--            <a href="#" style="color:black; text-decoration: none">More...</a>-->
<!--        </p>-->
<!--        <img src="../thumbnails/bac1.PNG" style="width: 400px">-->
<!--    </div>-->
<!--</div>-->
<!---->
<!---->
<!---->
<!--<div  style="width: 1300px">-->
<!--    <p align="left" style="margin-left: 100px; clear: left; margin-bottom: -0px; color:rgb(102, 204, 255); font-size: 36px ">Blog insert one</p>-->
<!--    <span style="margin-left: 120px; color: silver; font-size: 12px ">By mlondie | www.olovamp3.com</span>-->
<!---->
<!--    <div style="margin-left: 100px">-->
<!--        <p style="float: left; width: 750px;color: white;opacity: .6;">-->
<!--            mdsfa fjka fsfkjensaf mds afjska f,snfeka fnsiafdmsnfisnfajsknfuiesa fienaf dsfesa,f sfafaf eakf a fa-->
<!--            fslfmesailfd iemaf ieolmasd fosa dfoiea fienadfjhysabksufheaknflaifeioasnfsauiehsaknfiudnasfkdjas faskiufejankfnas-->
<!--            mdsfa fjka fsfkjensaf mds afjska f,snfeka fnsiafdmsnfisnfajsknfuiesa fienaf dsfesa,f sfafaf eakf a fa-->
<!--            fslfmesailfd iemaf ieolmasd fosa dfoiea fienadfjhysabksufheaknflaifeioasnfsauiehsaknfiudnasfkdjas faskiufejankfna-->
<!--            mdsfa fjka fsfkjensaf mds afjska f,snfeka fnsiafdmsnfisnfajsknfuiesa fienaf dsfesa,f sfafaf eakf a fa-->
<!--            fslfmesailfd iemaf ieolmasd fosa dfoiea fienadfjhysabksufheaknflaifeioasnfsauiehsaknfiudnasfkdjas faskiufejankfna-->
<!--            mdsfa fjka fsfkjensaf mds afjska f,snfeka fnsiafdmsnfisnfajsknfuiesa fienaf dsfesa,f sfafaf eakf a fa-->
<!--            fslfmesailfd iemaf ieolmasd fosa dfoiea fienadfjhysabksufheaknflaifeioasnfsauiehsaknfiudnasfkdjas faskiufejankfna-->
<!--            mdsfa fjka fsfkjensaf mds afjska f,snfeka fnsiafdmsnfisnfajsknfuiesa fienaf dsfesa,f sfafaf eakf a fa-->
<!--            fslfmesailfd iemaf ieolmasd fosa dfoiea fienadfjhysabksufheaknflaifeioasnfsauiehsaknfiudnasfkdjas faskiufejankfna-->
<!--            mdsfa fjka fsfkjensaf mds afjska f,snfeka fnsiafdmsnfisnfajsknfuiesa fienaf dsfesa,f sfafaf eakf a fa-->
<!--            fslfmesailfd iemaf ieolmasd fosa dfoiea fienadfjhysabksufheaknflaifeioasnfsauiehsaknfiudnasfkdjas faskiufejankfna<br>-->
<!--            <a href="#" style="color:black; text-decoration: none">More...</a>-->
<!--        </p>-->
<!--        <img src="../thumbnails/bac1.PNG" style="width: 400px">-->
<!--    </div>-->
<!--</div>-->

<?php echo $blog  ?>



<br><br><br>

<?php require '../footer/footer.php' ?>

</body>
</html>
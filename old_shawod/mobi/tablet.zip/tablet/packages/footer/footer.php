<div style="width: 96% ; margin-left: 5%" >
    <h1 align="center" style="font-size: 40px">Resources</h1>

    <a href="../../howitworks" class="resou">How it works</a>
    <span class="dot">&#8226;</span>
    <a href="../../createwebsite" class="resou2">How to create website</a>
    <span class="dot">&#8226;</span>
    <a href="../../seo" class="resou2">Searching Engine Optimization</a>
    <span class="dot">&#8226;</span>
    <a href="../../portalbenefits" class="resou2">Portal Beneft </a>
</div><br><br><br>


<div class="footer_links" style="width: 102%;height: 80px; background-color: rgb(51,51,51)">

    <div class="link_footer1">
        <a href="../../contactus">Contact us</a><br>
        <a href="../../aboutus">About us</a><br>
        <a href="../../faqs">FAQ's</a>
    </div>


    <img src="../thumbnails/find%20shawot.png" class="likeus" width="50" height="20" border="0" usemap="#four" />

    <map name="four">
        <span style="color: rgb(255,255,255);margin-left:-10%;  font-size: 22px; margin-top:15%">Follow us on</span>
        <area shape="rect"  coords="5,0,26,14" alt="Like Shawod" href="https://www.facebook.com/pages/Mp3Olova/1512466575638686">
        <area shape="rect" coords="40,0,72,14" alt="follow Shawod" href="http://www.twitter.com/mp3olova">
    </map>

    <div style="width:5%; height:20px;float:left; padding-left:8%; margin-top:55px; margin-left:-110px;">
        <a href="../blog" style="color:white;font-size: 22px; text-align:center; text-decoration:none">Blog</a>

    </div>
    <div  class="link_footer2" style="float: right; margin-top: 0%;">
        <a href="../../terms">Terms and Condition</a><br>
        <a href="../../privacy">Privacy policy</a><br>
        <a href="../../disclaimer">Disclaimer</a>
    </div>

</div>

<div class="footer_copy" style="width: 96%; height: auto; background-color: rgb(102,102,102)">
    <p align="center" style="color:rgb(255,255,255); font-size: 20px"> Copyright Shawod 2016 trademark are registered or unregistered trademark<br>
        of shawod in, shawod host , all right reserved other trademarks<br>
        are theire responsive owners
    </p>
    <p align="right" style="margin-right: 2% ; margin-top: -1%">Made with Love at Shawod</p>
</div>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title id="title">About us | Shawod</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <link rel="stylesheet" href="../css/small.css" type="text/css">
    <link rel="icon" type="image/ico" href="../thumbnails/favd.png">
    <script src="../js/normal.js"></script>
</head>
<body>
<div class="log">
    <a href="../home"><img src="../thumbnails/logog.png"></a>
</div>
<div class="navs">
    <ul>
        <li><a href="../home"> Home </a></li>

        <div class="dv"></div>
        <li><a href="../website"  >Website</a></li>

        <div class="dv"></div>
        <li ><a href="../packages"> Packages</a>
        </li>

        <div class="dv"></div>
        <li><a href="../portfolio"  >Portfolio</a></li>

        <div class="dv"></div>
        <li><a href="../seo"  >SEO</a></li>
        <div class="dv"></div>
        <li><a href="../domain"  >Domain</a></li>
        <div class="dv"></div>
        <li><a href="../hosting"  >Hosting</a></li>
</div><br>

<div  align="center" class="h_intro">
    <div align="center" class="intro_div">
        <span style="color: rgb(102,204,255)">About us</span>
    </div>
</div>

<div style="margin-left: 5%">
    <br>
 <img src="../thumbnails/logW.png" style="margin-left: 40%; margin-top: -3%; margin-bottom: -5%" >
<br><br><br>
        <div align="center"  style="font-family: Stencil; font-size: 24px; color: white; width: 90%">
            Let's make your <span style="color: rgb(102,204,255); ">Online Brand Ambassador !</span>
        </div>
    <div style="width: 96%">
    <p style="color: white; font-size: 22px ">Shawod is a small but capable Internet consulting company, we help our clients
        meet their goals using the most functional, state-of-the-art, and exciting Internet tools available..</p>

    <p style="color: white; font-size: 22px"> Shawod serves as a resource to people with little or no web development skills to quickly
        own a website. We also provide numerous Internet-related services, such as web design/development,
    application development, hosting ,domains and search engine optimization, to name a few. <br>Companies trust us with their technology
        requirements which enable them to focus on their core business.<br><br>
        We have been offering diverse and flexible solutions to clients of all sizes since 2014, trading as Freelancers..</p>

    </div>
</div>

<?php require '../footer/footer.php' ?>
</body>
</html>
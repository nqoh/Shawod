<!DOCTYPE>
<html>
<title></title>
    <head>

    </head>
     <style>
         body{
             background-color: rgb(234,237,238);
         }
     </style>
<body>
  <div style=" width: 900px; margin: 0px auto">
      <div style="background: rgb(79,79,79); width: 830px; height: 270px"><br>
          <img src="http://shawod.com/thumbnails/favw.png" style="margin-left: 380px"><br>
          <span align="center" style="font-size: 64px; margin-left: 150px;color: rgb(73,197,239)">Welcome to Shawod</span><br>
          <span align="center" style="font-size: 20px; margin-left: 200px;color: rgb(73,197,239)">WHERE YOUR IMAGINATION BECOME REALITY</span><br><br>
          <span style="margin-left: 340px;" align="center"><a href="http://portal.shawod.com"  style="color: rgb(73,197,239);text-decoration: none
;font-size:20px; background: white; padding: 7px; border-radius: 5px">VISIT PORTAL</a></span>
      </div>
      <div style="margin-top: 2px; background-color: white;width: 810px;padding: 10px ">
          <b style="font-size: 20px">Dear : Nqobile</b>
          <p>
              We  are so pleased that you have to decided to order Titanium Package form shawod.<br>
              This message simply save as confirmation of that order.<br><br>
              This email contain important information regarding your resent by shawod.com order.<br>
              Please save it for reference if you would like to cancel the status of your order or make any
              change to it please reply to dev@shawod.com
          </p>
          <span><b style="font-size: 20px">Customer Name : </b> Nqobile </span><br>
          <span><b style="font-size: 20px">Reference : </b> N3FrsQ </span><br>
          <span><b style="font-size: 20px">Product: </b> Titanium Package </span><br>
          <span><b style="font-size: 20px">Items(s) Total: </b> R14,699.99 </span><br>
          <span>Place on date: 2017/09/05</span><br>
          <p>
              We will send you an email once your order has been processed<br><br>
              Remember that Shawod will always here to provide you with Website,Domain,Hosting,SEO and excellent customer
              service.<br>
              If there is any thing more we can do to help, please don't hesitate to email us
          </p>
          <b style="font-size: 20px">Thank you </b><br>
          <span style="margin-left:50%">Find us on</span><br>
          <span>Sales Team</span><br>
          <span>Shawod Inc.</span>
          <a href=""><img src="../thumbnails/phone32.png" style="margin-left: 315px; cursor: pointer"></a>
          <a href=""><img src="../thumbnails/phone32.png" style="cursor: pointer"></a>
          <img src="../thumbnails/logoSb.png" style="float: right; margin-top: -50px">
      </div>
  </div>
</body>
</html>
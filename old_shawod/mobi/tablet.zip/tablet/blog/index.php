<?php
require '../connect.php';
$blog='';$text1='';
$q= mysqli_query($conn,"SELECT * FROM blog");
$images= Array('dns.jpg','webpromo.jpg','smpassword.jpg','smallbiz.jpg');
$i=0;
while ($row=mysqli_fetch_assoc($q)){
    $title=$row['title'];
    $s_title=$row['sub_title'];
    $txt=$row['text'];
    $id=$row['id'];

if(strlen($txt) > 1140){
    $text1 = substr($txt, 0, 1140 ).' ...';
}
    $blog.="<div  style=\"width: 90%; margin-left: 5%\">
    <p align=\"left\" style=\"clear: left; margin-bottom: -0px; color:rgb(102, 204, 255); font-size: 28px \">$title</p>
    <span style=\" color: silver; font-size: 22px \">$s_title</span>
    <div style=\"\">
     <p style=\"float: left; color: white;opacity: .6;font-size: 24px\">
    
       
              $text1 <br>
            <a href=\"../blog/$id\" style=\"color:black;color:rgb(102, 204, 255); text-decoration: none\">More...</a>
        </p>
        <img src=\"../thumbnails/$images[$i]\" style=\"width: 90%; height:80% \">
    </div>
</div>";
$i++;


}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title id="title">Blog | Shawod</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <link rel="stylesheet" href="../css/small.css" type="text/css">
    <link rel="icon" type="image/ico" href="../thumbnails/favd.png">
</head>
<script src="../js/normal.js"></script>
<body>
<div  id="scroll_up" style="background-color:#333333;" onclick="scroll_ups()">
    <img src="../thumbnails/go%20up2.png" width="79px" style="margin-top: 6px" >
</div>
<div class="log">
    <a href="../home"><img src="../thumbnails/logog.png"></a>
</div>

<div class="navs">
    <ul>
        <li><a href="../home"> Home </a></li>

        <div class="dv"></div>
        <li><a href="../website"  >Website</a></li>

        <div class="dv"></div>
        <li ><a href="../packages"> Packages</a>
        </li>

        <div class="dv"></div>
        <li><a href="../portfolio"  >Portfolio</a></li>

        <div class="dv"></div>
        <li><a href="../seo"  >SEO</a></li>
        <div class="dv"></div>
        <li><a href="../domain"  >Domain</a></li>
        <div class="dv"></div>
        <li><a href="../hosting"  >Hosting</a></li>
</div><br>

<div  align="center" class="h_intro">
    <div align="center" class="intro_div">
        <span style="color: rgb(102,204,255)">Blog</span>
    </div>
</div>
<?php echo $blog  ?>

<?php require '../footer/footer.php' ?>

</body>
</html>
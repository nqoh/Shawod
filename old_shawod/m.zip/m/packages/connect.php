<?php
$conn=mysqli_connect("localhost","shawod_shawod","3244Shawod") or die("Not connected ");
mysqli_select_db($conn,"shawod_shawod") or die("Database not finde");
?>
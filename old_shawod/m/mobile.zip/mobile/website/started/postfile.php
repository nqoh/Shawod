<?php
// echo  substr(date('Yd'),2,5)."".rand(10,99);
//exit();
include_once('../connect.php');
if(isset($_POST['email'])){
    $email=$_POST['email'];
    if(filter_var($email , FILTER_VALIDATE_EMAIL) ){
     
    }else{
        echo "Invalid email address";
    }
}
if(isset($_POST['name'])  && isset($_POST['contact'])  && isset($_POST['text'])){
    $nam = $_POST['name'];
    $email=$_POST['emails'];
    $cont =$_POST['contact'];
    $txt =$_POST['text'];
	$pack=$_POST['pack'];
	$price=$_POST['price'];
	$discount=$_POST['discount'];
	$feature=$_POST['feature'];
    $ref="WS".rand(10,99).date("s");
	$user_id=date("z").substr($ref,2,6);
	$a=0;
	$pass1= substr(md5($email),4,6);
	$pass= md5($pass1);

    $chek=mysqli_query($conn,"SELECT * FROM `not_approved` WHERE email='$email'");
    if(mysqli_num_rows($chek)== 0) {
        $save = mysqli_query($conn, "INSERT INTO `not_approved` VALUES(null, '$nam', '$email', '$cont', '$txt', '$pack', '$feature', '$ref', '$user_id','$pass1','', $a, '$price','$discount' ,'', CURRENT_TIMESTAMP)");
        $fk=mysqli_insert_id($conn);
        mysqli_query($conn,"INSERT INTO `login` VALUES(null,'$user_id','$pass','$fk',0,'' ,'' )");
        echo "Your reference number is <b style='color: rgb(51,204,255)'>" . $ref . "</b> please save it<br><br> Thank you " . $nam . " we will get back to you soon";
    }else{
        echo "You are already exit in database";
    }
}
?>
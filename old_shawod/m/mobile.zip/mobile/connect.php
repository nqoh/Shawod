<?php
 $conn=mysqli_connect("localhost","root","") or die("Not connected ");
 mysqli_select_db($conn,"shawod") or die("Database not finde");
?>
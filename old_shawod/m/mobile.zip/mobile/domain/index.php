<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title id="title">Domain | Shawod</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <link rel="stylesheet" href="../css/small.css" type="text/css">
    <link rel="icon" type="image/ico" href="../thumbnails/favd.png">
</head>

<body>
<div class="log">
    <a href="../home"><img src="../thumbnails/logog.png"></a>
</div>

<div class="navs">
    <ul>
        <li><a href="../home"> Home </a></li>

        <div class="dv"></div>
        <li><a href="../website"  >Website</a></li>

        <div class="dv"></div>
        <li ><a href="../packages"> Packages</a>
        </li>

        <div class="dv"></div>
        <li><a href="../portfolio"  >Portfolio</a></li>

        <div class="dv2"></div>
        <li><a href="../seo"  >SEO</a></li>
        <div class="dv2"></div>
        <li><a href="../domain" style=" opacity:1;color: rgb(140,140,140)" >Domain</a></li>
        <div class="dv2"></div>
        <li><a href="../hosting"  >Hosting</a></li>
</div><br>

<div  align="center" class="h_intro">
    <div align="center" class="intro_div">
        <span style="color: rgb(102,204,255)">Domain</span>
    </div>
    <p align="center" style="color:white;">Shawod Domain Name Search tool can instantly find the domain name that you've been looking for, simple
        domain set up - no technical skills needed.<br> forward your enquiries to info@shawod.com</p>
    <img src="../thumbnails/dsoon.jpg" width="90%">
</div>

<?php require '../footer/footer.php' ?>

</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title id="title">Contact us | Shawod</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <link rel="stylesheet" href="../css/small.css" type="text/css">
    <link rel="icon" type="image/ico" href="../thumbnails/favd.png">
</head>

<body>

<div class="log">
    <a href="../home"><img src="../thumbnails/logog.png"></a>
</div>
<div class="navs">
    <ul>
        <li><a href="../home"> Home </a></li>

        <div class="dv"></div>
        <li><a href="../website"  >Website</a></li>

        <div class="dv"></div>
        <li ><a href="../packages"> Packages</a>
        </li>


        <div class="dv"></div>
        <li><a href="../portfolio"  >Portfolio</a></li>

        <div class="dv2"></div>
        <li><a href="../seo"  >SEO</a></li>
        <div class="dv2"></div>
        <li><a href="../domain"  >Domain</a></li>
        <div class="dv2"></div>
        <li><a href="../hosting"  >Hosting</a></li>
</div><br>

<div  align="center" class="h_intro">
    <div align="center" class="intro_div">
        <span style="color: rgb(102,204,255)">Contact us</span>
    </div>
</div>

<div  style="width: 90%; margin-left: 5%;">
    <h3 style="color: white" align="center"><u>If you have any queries or want to chat about your Project please go right ahead.</u></h3>
    <h4 style="color: white" align="center"> Our team is always standing by to assist you.</h4>

    <form class="form" >
        <span class="fill_in">Complete this form, one of our expects will get back to you.</span><br>

        <br><label class="lebel">Name<span style="color:red"> * </span></label><span style="color: red" id="namee_error"></span><br>
        <input type="text" class="text-field3" id="namee" onblur="name_out('namee','namee_error')" onfocus="mouse_in('namee')"><br>

        <br><label class="lebel">E-mail<span style="color:red"> * </span></label><span id="emaile_error" style="color: red"></span><br>

        <input type="text" class="text-field3" id="emaile" onblur="check_email('emaile','emaile_error')" onfocus="mouse_in('emaile')" ><br>

        <br><label class="lebel">Subject</label>&nbsp;&nbsp;<span id="sub_error" style="color: red"></span><br>
        <input type="text" class="text-field3" id="subjs" onblur="subj('subjs','sub_error')"  onfocus="mouse_in('subjs') "><br>

        <br><label class="lebel">Query<span style="color:red"> * </span></label><span style="color: red" id="describes_error"></span><br>

    <textarea style=" border: 1px solid #ccc;"  id="textarea" onblur="texts('textareas','describes_error')" onfocus="mouse_in('textareas')" ></textarea>

        <input type="submit" class="submit_btn">
    </form>

    </div><br>
</div>

<?php require '../footer/footer.php' ?>

</body>
</html>